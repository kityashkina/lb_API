using Application.DTOs;
using Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Web.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class CalculatorController : ControllerBase
{
    private readonly ICalculationService _service;

    public CalculatorController(ICalculationService service)
    {
        _service = service;
    }

    [HttpPost]
    public IActionResult Create(CreateCalculationDto dto)
    {
        var result = _service.Create(dto);
        return Ok(result);
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(_service.GetAll());
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var calc = _service.GetById(id);
        if (calc == null)
            return NotFound();
        return Ok(calc);
    }
}