﻿using Application.DTOs;
using Application.Interfaces;
using Domain.Entities;

namespace Application.Services;

public class CalculationService : ICalculationService
{
    private readonly ICalculationRepository _repository;

    public CalculationService(ICalculationRepository repository)
    {
        _repository = repository;
    }

    public Calculation Create(CreateCalculationDto dto)
    {
        double result = dto.A + dto.B;

        var calculation = new Calculation
        {
            A = dto.A,
            B = dto.B,
            Result = result,
            CreatedAt = DateTime.Now
        };

        _repository.Add(calculation);
        return calculation;
    }

    public List<Calculation> GetAll()
    {
        return _repository.GetAll();
    }

    public Calculation? GetById(int id)
    {
        return _repository.GetById(id);
    }
}