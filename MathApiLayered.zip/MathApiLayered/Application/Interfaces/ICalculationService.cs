﻿using Domain.Entities;
using Application.DTOs;

namespace Application.Interfaces;

public interface ICalculationService
{
    Calculation Create(CreateCalculationDto dto);
    List<Calculation> GetAll();
    Calculation? GetById(int id);
}