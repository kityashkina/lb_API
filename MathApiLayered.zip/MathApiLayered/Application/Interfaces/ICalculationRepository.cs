﻿using Domain.Entities;

namespace Application.Interfaces;

public interface ICalculationRepository
{
    void Add(Calculation calculation);
    List<Calculation> GetAll();
    Calculation? GetById(int id);
}
