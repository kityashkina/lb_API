﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data;

public class AppDbContext : DbContext
{
    public DbSet<Calculation> Calculations => Set<Calculation>();

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }
}