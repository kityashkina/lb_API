﻿using Application.Interfaces;
using Domain.Entities;
using Infrastructure.Data;

namespace Infrastructure.Repositories;

public class CalculationRepository : ICalculationRepository
{
    private readonly AppDbContext _context;

    public CalculationRepository(AppDbContext context)
    {
        _context = context;
    }

    public void Add(Calculation calculation)
    {
        _context.Calculations.Add(calculation);
        _context.SaveChanges();
    }

    public List<Calculation> GetAll()
    {
        return _context.Calculations.ToList();
    }

    public Calculation? GetById(int id)
    {
        return _context.Calculations.FirstOrDefault(x => x.Id == id);
    }
}