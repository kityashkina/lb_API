﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Windows;
using CalcWPFClient.Models;

namespace CalcWPFClient
{
    public partial class MainWindow : Window
    {
        HttpClient client = new HttpClient();

        public MainWindow()
        {
            InitializeComponent();
            client.BaseAddress = new Uri("https://localhost:7039/");
        }

        private async void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(TextBoxA.Text);
            double b = Convert.ToDouble(TextBoxB.Text);

            var request = new CalcRequest { A = a, B = b };

            var response = await client.PostAsJsonAsync("api/calculator/calculate", request);
            string result = await response.Content.ReadAsStringAsync();

            ResultTextBlock.Text = result;
        }

        private async void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var history = await client.GetFromJsonAsync<List<Calculation>>("api/calculator");

            var displayItems = history.Select(c =>
                $"{c.A} + {c.B} = {c.Result}  ({c.CreatedAt:HH:mm:ss})"
            ).ToList();

            HistoryListBox.ItemsSource = displayItems;
        }
    }

}