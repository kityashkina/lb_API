﻿namespace WebApplication1.Models
{
    public class CreateCalculationDto
    {
        public double A { get; set; }
        public double B { get; set; }
    }
}