﻿using MathAPI.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication1;
using WebApplication1.Models;

namespace MathAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CalculatorController : ControllerBase
{
    private readonly AppDbContext _context;
    public CalculatorController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("calculate")]
    public double Calculate(CalcRequest request)
    {
        double result = request.A + request.B;
        var calculation = new Calculation
        {
            A = request.A,
            B = request.B,
            Result = result,
            CreatedAt = DateTime.Now
        };
        _context.Calculations.Add(calculation);
        _context.SaveChanges();
        return result;
    }

    [HttpGet]
    public List<Calculation> GetAll()
    {
        return _context.Calculations.ToList();
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var calc = _context.Calculations.FirstOrDefault(c => c.Id == id);
        if (calc == null)
            return NotFound();
        return Ok(calc);
    }

    [HttpGet("add/{a}/{b}")]
    public IActionResult AddFromUrl(double a, double b)
    {
        double result = a + b; 
        return Ok(result);
    }
}