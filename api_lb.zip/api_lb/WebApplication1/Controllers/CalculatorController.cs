﻿using MathAPI.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication1;
using WebApplication1.Models;

namespace MathAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CalculatorController : ControllerBase
{
    private readonly AppDbContext _context;
    public CalculatorController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("calculate")]
    public double Calculate(CalcRequest request)
    {
        double result = request.A + request.B;
        var calculation = new Calculation
        {
            A = request.A,
            B = request.B,
            Result = result,
            CreatedAt = DateTime.Now
        };
        _context.Calculations.Add(calculation);
        _context.SaveChanges();
        return result;
    }

    [HttpGet]
    public List<Calculation> GetAll()
    {
        return _context.Calculations.ToList();
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var calc = _context.Calculations.FirstOrDefault(c => c.Id == id);
        if (calc == null)
            return NotFound();
        return Ok(calc);
    }

    [HttpGet("add/{a}/{b}")]
    public IActionResult AddFromUrl(double a, double b)
    {
        double result = a + b; 
        return Ok(result);
    }

    [HttpGet("calc/{a}/{b}")]
    public IActionResult CalculateFromRoute(double a, double b)
    {
        double result = a + b; // операция сложения по вашему варианту
        return Ok(new { A = a, B = b, Result = result });
    }

    [HttpGet("query")]
    public IActionResult CalculateFromQuery(double a, double b)
    {
        double result = a + b;
        return Ok(new { A = a, B = b, Result = result });
    }

    [HttpGet("dto/{id}")]
    public ActionResult<CalculationDto> GetDto(int id)
    {
        var calc = _context.Calculations.FirstOrDefault(x => x.Id == id);
        if (calc == null)
            return NotFound();

        var dto = new CalculationDto
        {
            A = calc.A,
            B = calc.B,
            Result = calc.Result
        };
        return Ok(dto);
    }

    [HttpGet("list")]
    public IActionResult GetList()
    {
        var list = _context.Calculations
            .Select(c => new CalculationDto
            {
                A = c.A,
                B = c.B,
                Result = c.Result
            })
            .ToList();
        return Ok(list);
    }

    [HttpPost]
    public IActionResult Create(CreateCalculationDto dto)
    {
        // Вычисление результата (операция сложения по вашему варианту)
        double result = dto.A + dto.B;

        // Создаём объект Calculation для сохранения в БД
        var calculation = new Calculation
        {
            A = dto.A,
            B = dto.B,
            Result = result,
            CreatedAt = DateTime.Now
        };

        // Сохраняем в базу данных
        _context.Calculations.Add(calculation);
        _context.SaveChanges();

        // Возвращаем созданный ресурс с правильным HTTP-кодом 201
        return CreatedAtAction(nameof(GetById), new { id = calculation.Id }, calculation);
    }
}